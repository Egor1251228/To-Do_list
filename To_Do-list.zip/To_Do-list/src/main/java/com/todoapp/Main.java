package com.todoapp;

public class Main {
    public static void main(String[] args) {
        System.out.println("Запуск Менеджера Задач...");

        try {
            TaskManager taskManager = new TaskManager();
            taskManager.showMenu();
        } catch (Exception e) {
            System.out.println("Критическая ошибка: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
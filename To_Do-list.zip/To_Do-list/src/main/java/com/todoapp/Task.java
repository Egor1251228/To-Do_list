package com.todoapp;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Task {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private final String id;
    private String title;
    private String description;
    private LocalDate dueDate;
    private TaskPriority priority;
    private boolean completed;
    private String category;

    public Task(String title, String description, LocalDate dueDate, TaskPriority priority, String category) {
        this.id = generateId();
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.priority = priority;
        this.category = category;
        this.completed = false;
    }

    public Task(String id, String title, String description, LocalDate dueDate, TaskPriority priority, String category, boolean completed) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.priority = priority;
        this.category = category;
        this.completed = completed;
    }

    private String generateId() {
        return "T" + System.currentTimeMillis() + "_" + (int)(Math.random() * 1000);
    }

    // Геттеры и сеттеры...
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public LocalDate getDueDate() { return dueDate; }
    public TaskPriority getPriority() { return priority; }
    public boolean isCompleted() { return completed; }
    public String getCategory() { return category; }

    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public void setPriority(TaskPriority priority) { this.priority = priority; }
    public void setCompleted(boolean completed) { this.completed = completed; }
    public void setCategory(String category) { this.category = category; }

    @Override
    public String toString() {
        String status = completed ? "ВЫПОЛНЕНА" : "НЕ ВЫПОЛНЕНА";
        String formattedDate = dueDate != null ? dueDate.format(DATE_FORMATTER) : "Не указана";
        return String.format(
                "ID: %s\nЗадача: %s\nОписание: %s\nСрок: %s\nПриоритет: %s\nКатегория: %s\nСтатус: %s\n%s",
                id, title, description, formattedDate, priority.getDisplayName(), category, status,
                "─".repeat(50)
        );
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return Objects.equals(id, task.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}

package com.todoapp;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Менеджер задач с функциями CRUD и сохранением в JSON
 */
public class TaskManager {
    private static final String FILE_NAME = "tasks.json";
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private Map<String, Task> tasks;
    private Scanner scanner;

    public TaskManager() {
        this.tasks = new HashMap<>();
        this.scanner = new Scanner(System.in);
        loadTasksFromFile();
    }

    /**
     * Главное меню приложения
     */
    public void showMenu() {
        while (true) {
            System.out.println("\n" + "═".repeat(60));
            System.out.println("            МЕНЕДЖЕР ЗАДАЧ");
            System.out.println("═".repeat(60));
            System.out.println("1.  Показать все задачи");
            System.out.println("2.  Создать новую задачу");
            System.out.println("3. ️  Редактировать задачу");
            System.out.println("4.  Удалить задачу");
            System.out.println("5.  Отметить выполненной/невыполненной");
            System.out.println("6.  Сортировать по дате");
            System.out.println("7.  Поиск задач");
            System.out.println("8.  Сохранить задачи");
            System.out.println("0.  Выход");
            System.out.println("═".repeat(60));
            System.out.print("Выберите действие: ");

            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); // очистка буфера

                switch (choice) {
                    case 1:
                        showAllTasks();
                        break;
                    case 2:
                        createTask();
                        break;
                    case 3:
                        editTask();
                        break;
                    case 4:
                        deleteTask();
                        break;
                    case 5:
                        toggleTaskCompletion();
                        break;
                    case 6:
                        sortTasksByDate();
                        break;
                    case 7:
                        searchTasks();
                        break;
                    case 8:
                        saveTasksToFile();
                        break;
                    case 0:
                        saveTasksToFile();
                        System.out.println(" Задачи сохранены. До свидания!");
                        return;
                    default:
                        System.out.println(" Неверный выбор. Попробуйте снова.");
                }
            } catch (InputMismatchException e) {
                System.out.println(" Ошибка: введите число от 0 до 8");
                scanner.nextLine(); // очистка неверного ввода
            } catch (Exception e) {
                System.out.println(" Произошла ошибка: " + e.getMessage());
            }
        }
    }

    /**
     * Создание новой задачи
     */
    private void createTask() {
        System.out.println("\n" + "─".repeat(40));
        System.out.println("СОЗДАНИЕ НОВОЙ ЗАДАЧИ");
        System.out.println("─".repeat(40));

        System.out.print("Введите название задачи: ");
        String title = scanner.nextLine().trim();

        if (title.isEmpty()) {
            System.out.println(" Название задачи не может быть пустым!");
            return;
        }

        System.out.print("Введите описание задачи: ");
        String description = scanner.nextLine().trim();

        LocalDate dueDate = readDate("Введите срок выполнения (дд.мм.гггг) или Enter чтобы пропустить: ");

        TaskPriority priority = readPriority();

        System.out.print("Введите категорию: ");
        String category = scanner.nextLine().trim();
        if (category.isEmpty()) category = "Общее";

        Task task = new Task(title, description, dueDate, priority, category);
        tasks.put(task.getId(), task);

        System.out.println(" Задача создана с ID: " + task.getId());
    }

    /**
     * Чтение даты с обработкой ошибок
     */
    private LocalDate readDate(String prompt) {
        while (true) {
            System.out.print(prompt);
            String dateInput = scanner.nextLine().trim();

            if (dateInput.isEmpty()) {
                return null;
            }

            try {
                return LocalDate.parse(dateInput, DATE_FORMATTER);
            } catch (DateTimeParseException e) {
                System.out.println(" Неверный формат даты. Используйте дд.мм.гггг");
            }
        }
    }

    /**
     * Чтение приоритета с обработкой ошибок
     */
    private TaskPriority readPriority() {
        while (true) {
            System.out.println("Выберите приоритет:");
            System.out.println("1. Низкий");
            System.out.println("2. Средний");
            System.out.println("3. Высокий");
            System.out.println("4. Срочный");
            System.out.print("Ваш выбор (1-4): ");

            String input = scanner.nextLine().trim();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= 4) {
                    return TaskPriority.fromInt(choice);
                } else {
                    System.out.println(" Введите число от 1 до 4");
                }
            } catch (NumberFormatException e) {
                System.out.println(" Неверный формат числа");
            }
        }
    }

    /**
     * Показать все задачи
     */
    private void showAllTasks() {
        if (tasks.isEmpty()) {
            System.out.println("\n Список задач пуст");
            return;
        }

        System.out.println("\n" + "═".repeat(60));
        System.out.println("                ВСЕ ЗАДАЧИ (" + tasks.size() + ")");
        System.out.println("═".repeat(60));

        for (Task task : tasks.values()) {
            System.out.println(task);
        }
    }

    /**
     * Редактирование задачи
     */
    private void editTask() {
        if (tasks.isEmpty()) {
            System.out.println("\n Нет задач для редактирования");
            return;
        }

        showAllTasks();
        System.out.print("\nВведите ID задачи для редактирования: ");
        String taskId = scanner.nextLine().trim();

        Task task = tasks.get(taskId);
        if (task == null) {
            System.out.println("❌ Задача с ID '" + taskId + "' не найдена");
            return;
        }

        System.out.println("\nРедактирование задачи:");
        System.out.println(task);

        System.out.print("Новое название (текущее: " + task.getTitle() + "): ");
        String newTitle = scanner.nextLine().trim();
        if (!newTitle.isEmpty()) {
            task.setTitle(newTitle);
        }

        System.out.print("Новое описание (текущее: " + task.getDescription() + "): ");
        String newDescription = scanner.nextLine().trim();
        if (!newDescription.isEmpty()) {
            task.setDescription(newDescription);
        }

        LocalDate newDueDate = readDate("Новый срок (текущий: " +
                (task.getDueDate() != null ? task.getDueDate().format(DATE_FORMATTER) : "Не указан") + "): ");
        if (newDueDate != null) {
            task.setDueDate(newDueDate);
        }

        System.out.println("Текущий приоритет: " + task.getPriority().getDisplayName());
        System.out.print("Изменить приоритет? (y/n): ");
        if (scanner.nextLine().trim().equalsIgnoreCase("y")) {
            task.setPriority(readPriority());
        }

        System.out.print("Новая категория (текущая: " + task.getCategory() + "): ");
        String newCategory = scanner.nextLine().trim();
        if (!newCategory.isEmpty()) {
            task.setCategory(newCategory);
        }

        System.out.println(" Задача обновлена");
    }

    /**
     * Удаление задачи
     */
    private void deleteTask() {
        if (tasks.isEmpty()) {
            System.out.println("\n Нет задач для удаления");
            return;
        }

        showAllTasks();
        System.out.print("\nВведите ID задачи для удаления: ");
        String taskId = scanner.nextLine().trim();

        Task removedTask = tasks.remove(taskId);
        if (removedTask != null) {
            System.out.println(" Задача удалена: " + removedTask.getTitle());
        } else {
            System.out.println(" Задача с ID '" + taskId + "' не найдена");
        }
    }

    /**
     * Переключение статуса выполнения задачи
     */
    private void toggleTaskCompletion() {
        if (tasks.isEmpty()) {
            System.out.println("\n Нет задач для изменения");
            return;
        }

        showAllTasks();
        System.out.print("\nВведите ID задачи для изменения статуса: ");
        String taskId = scanner.nextLine().trim();

        Task task = tasks.get(taskId);
        if (task != null) {
            task.setCompleted(!task.isCompleted());
            String status = task.isCompleted() ? "выполненной" : "невыполненной";
            System.out.println(" Задача отмечена как " + status);
        } else {
            System.out.println(" Задача с ID '" + taskId + "' не найдена");
        }
    }

    /**
     * Сортировка задач по дате
     */
    private void sortTasksByDate() {
        if (tasks.isEmpty()) {
            System.out.println("\n Нет задач для сортировки");
            return;
        }

        List<Task> sortedTasks = tasks.values().stream()
                .sorted(Comparator.comparing(
                        Task::getDueDate,
                        Comparator.nullsLast(Comparator.naturalOrder())
                ))
                .collect(Collectors.toList());

        System.out.println("\n" + "═".repeat(60));
        System.out.println("               ЗАДАЧИ ОТСОРТИРОВАНЫ ПО ДАТЕ");
        System.out.println("═".repeat(60));
        for (Task task : sortedTasks) {
            System.out.println(task);
        }
    }

    /**
     * Поиск задач по различным атрибутам
     */
    private void searchTasks() {
        if (tasks.isEmpty()) {
            System.out.println("\n Нет задач для поиска");
            return;
        }

        System.out.println("\n" + "─".repeat(40));
        System.out.println("ПОИСК ЗАДАЧ");
        System.out.println("─".repeat(40));
        System.out.println("1. По названию");
        System.out.println("2. По описанию");
        System.out.println("3. По категории");
        System.out.println("4. По приоритету");
        System.out.println("5. По статусу выполнения");
        System.out.print("Выберите тип поиска: ");

        try {
            int searchType = scanner.nextInt();
            scanner.nextLine(); // очистка буфера

            System.out.print("Введите поисковый запрос: ");
            String query = scanner.nextLine().trim().toLowerCase();

            List<Task> foundTasks = new ArrayList<>();
            for (Task task : tasks.values()) {
                if (matchesSearch(task, query, searchType)) {
                    foundTasks.add(task);
                }
            }

            if (foundTasks.isEmpty()) {
                System.out.println(" Задачи не найдены");
            } else {
                System.out.println("\n" + "═".repeat(60));
                System.out.println("            РЕЗУЛЬТАТЫ ПОИСКА (" + foundTasks.size() + ")");
                System.out.println("═".repeat(60));
                for (Task task : foundTasks) {
                    System.out.println(task);
                }
            }
        } catch (InputMismatchException e) {
            System.out.println(" Неверный выбор");
            scanner.nextLine();
        }
    }

    /**
     * Проверка соответствия задачи поисковому запросу
     */
    private boolean matchesSearch(Task task, String query, int searchType) {
        switch (searchType) {
            case 1:
                return task.getTitle().toLowerCase().contains(query);
            case 2:
                return task.getDescription().toLowerCase().contains(query);
            case 3:
                return task.getCategory().toLowerCase().contains(query);
            case 4:
                return task.getPriority().getDisplayName().toLowerCase().contains(query);
            case 5:
                boolean completedQuery = query.contains("выполн") || query.contains("done") || query.equals("✓");
                return task.isCompleted() == completedQuery;
            default:
                return false;
        }
    }

    /**
     * Сохранение задач в JSON файл
     */
    public void saveTasksToFile() {
        try {
            JSONArray jsonArray = new JSONArray();

            for (Task task : tasks.values()) {
                JSONObject jsonTask = new JSONObject();
                jsonTask.put("id", task.getId());
                jsonTask.put("title", task.getTitle());
                jsonTask.put("description", task.getDescription());
                jsonTask.put("dueDate", task.getDueDate() != null ?
                        task.getDueDate().format(DATE_FORMATTER) : null);
                jsonTask.put("priority", task.getPriority().name());
                jsonTask.put("category", task.getCategory());
                jsonTask.put("completed", task.isCompleted());
                jsonArray.put(jsonTask);
            }

            try (FileWriter file = new FileWriter(FILE_NAME)) {
                file.write(jsonArray.toString(2)); // pretty print with indentation 2
            }

            System.out.println(" Задачи сохранены в файл: " + FILE_NAME);
        } catch (IOException e) {
            System.out.println(" Ошибка при сохранении файла: " + e.getMessage());
        }
    }

    /**
     * Загрузка задач из JSON файла
     */
    private void loadTasksFromFile() {
        try {
            if (!Files.exists(Paths.get(FILE_NAME))) {
                System.out.println(" Файл задач не найден. Будет создан новый.");
                return;
            }

            String content = new String(Files.readAllBytes(Paths.get(FILE_NAME)));
            JSONArray jsonArray = new JSONArray(content);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonTask = jsonArray.getJSONObject(i);

                String id = jsonTask.getString("id");
                String title = jsonTask.getString("title");
                String description = jsonTask.optString("description", "");

                LocalDate dueDate = null;
                String dueDateStr = jsonTask.optString("dueDate", null);
                if (dueDateStr != null && !dueDateStr.isEmpty()) {
                    dueDate = LocalDate.parse(dueDateStr, DATE_FORMATTER);
                }

                TaskPriority priority = TaskPriority.valueOf(jsonTask.getString("priority"));
                String category = jsonTask.optString("category", "Общее");
                boolean completed = jsonTask.optBoolean("completed", false);

                Task task = new Task(id, title, description, dueDate, priority, category, completed);
                tasks.put(id, task);
            }

            System.out.println(" Загружено задач: " + tasks.size());
        } catch (IOException e) {
            System.out.println(" Ошибка при загрузке файла: " + e.getMessage());
        } catch (Exception e) {
            System.out.println(" Ошибка при чтении данных: " + e.getMessage());
        }
    }
}